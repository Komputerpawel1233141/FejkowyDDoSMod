package pl.fejkowy.ddos;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class FejkowyDdosClient implements ClientModInitializer {
    private static KeyBinding toggleKey;
    private static boolean active = false;
    private static int ticks = 0;
    private static final List<String> LOGS = new ArrayList<>();

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.fejkowy_ddos.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_K,
                "category.fejkowy_ddos"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                active = !active;
                ticks = 0;
                LOGS.clear();
                if (active) {
                    addLog("[SIM] Uruchomiono pokaz demonstracyjny");
                    addLog("[SIM] Tryb: WYŁĄCZNIE WIZUALNY");
                    addLog("[SIM] Brak połączeń sieciowych");
                } else {
                    addLog("[SIM] Zatrzymano symulację");
                }
            }

            if (active) {
                ticks++;
                if (ticks % 40 == 0) {
                    int stage = (ticks / 40) % 5;
                    switch (stage) {
                        case 0 -> addLog("[SIM] Analiza pakietów: 0 wysłanych");
                        case 1 -> addLog("[SIM] Test obciążenia: tylko animacja");
                        case 2 -> addLog("[SIM] Odpowiedź serwera: DEMO");
                        case 3 -> addLog("[SIM] Ruch sieciowy: 0 B");
                        default -> addLog("[SIM] Status: symulacja działa");
                    }
                }
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            if (!active) return;
            renderOverlay(drawContext, MinecraftClient.getInstance());
        });
    }

    private static void addLog(String line) {
        LOGS.add(line);
        while (LOGS.size() > 6) LOGS.remove(0);
    }

    private static void renderOverlay(DrawContext context, MinecraftClient client) {
        int x = 12;
        int y = 12;
        int width = 310;
        int height = 142;
        context.fill(x, y, x + width, y + height, 0xD9000800);
        context.fill(x, y, x + width, y + 2, 0xFF29FF78);
        context.drawText(client.textRenderer, Text.literal("FAKE NETWORK CONSOLE  //  DEMO"), x + 9, y + 8, 0xFF29FF78, false);
        context.drawText(client.textRenderer, Text.literal("TYLKO EFEKT WIZUALNY — BRAK ATAKU"), x + 9, y + 22, 0xFFFFD166, false);

        int lineY = y + 40;
        for (String line : LOGS) {
            context.drawText(client.textRenderer, Text.literal(line), x + 9, lineY, 0xFFE0FFE8, false);
            lineY += 12;
        }

        int barX = x + 9;
        int barY = y + height - 17;
        int barWidth = width - 18;
        context.fill(barX, barY, barX + barWidth, barY + 6, 0xFF26352B);
        int progress = (ticks * 3) % (barWidth + 1);
        context.fill(barX, barY, barX + progress, barY + 6, 0xFF29FF78);
    }
}
