# Fejkowy DDoS Mod — Minecraft 1.21.1 / Fabric

To jest **wyłącznie wizualna symulacja** terminala. Mod nie wysyła pakietów, nie wykonuje połączeń sieciowych i nie atakuje serwerów.

## Funkcje
- Klawisz **K** włącza/wyłącza panel.
- Zielony panel terminala, komunikaty demonstracyjne i animowany pasek postępu.
- Działa po stronie klienta; nie wymaga instalacji na serwerze.

## Wymagania
- Minecraft 1.21.1
- Java 21
- Fabric Loader oraz Fabric API
- Gradle (albo otwarcie folderu w IntelliJ IDEA)

## Budowanie pliku JAR
1. Otwórz folder projektu w IntelliJ IDEA lub terminalu.
2. Uruchom: `gradle build`
3. Gotowy JAR będzie w `build/libs/fejkowy-ddos-mod-1.0.0.jar`.

Jeśli Gradle zgłosi problem z pobraniem wersji Loom, otwórz projekt z internetem i pozwól Gradle odświeżyć zależności.
